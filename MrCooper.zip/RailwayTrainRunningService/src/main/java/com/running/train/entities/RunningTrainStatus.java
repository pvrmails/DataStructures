package com.running.train.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "RUNNING_TRAIN_STATUS")
public class RunningTrainStatus {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ROUTING_SEQUENCE")
	private int id;

	@Column(name = "TRIP_ID")
	private int tripId;

	@Column(name = "TRAIN_ID")
	private Long trainId;

	@Column(name = "STATION_NAME")
	private String stationName;

	@Column(name = "ARRIVAL_TIME", nullable = true)
	private Date arrivalTime;
	
	@Column(name = "DEPARTURE_TIME", nullable = true)
	private Date departureTime;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTripId() {
		return tripId;
	}

	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	
	public Long getTrainId() {
		return trainId;
	}

	public void setTrainId(Long trainId) {
		this.trainId = trainId;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	
	public Date getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Date arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	@Override
	public String toString() {
		return "RunningTrainStatus [id=" + id + ", tripId=" + tripId + ", trainId=" + trainId + ", stationName="
				+ stationName + ", arrivalTime=" + arrivalTime + ", departureTime=" + departureTime + "]";
	}	
}	
