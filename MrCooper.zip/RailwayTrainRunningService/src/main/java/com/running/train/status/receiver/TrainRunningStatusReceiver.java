package com.running.train.status.receiver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.running.train.service.RailwayTrainRunningService;
import com.status.update.running.train.model.TrainUpdateStatus;


/**
 * This receiver picks the journey updates from the queue and updates the Train Running Table
 * 
 * @author RAJASEKAR PV
 * 
 * @since 21 / 07 / 2020
 */
@Service
public class TrainRunningStatusReceiver {
	
	Logger logger = LoggerFactory.getLogger(TrainRunningStatusReceiver.class);
	
	@Autowired
	private RailwayTrainRunningService railwayTrainRunningService;
	
	@RabbitListener(queues = "${train-running-service.rabbitmq.queueName}")
	public void receiveTrainUpdateStatus(final TrainUpdateStatus trainStatusUpdate) {
		logger.info("Received Update for : TrainNumber - {}, RouteNumber - {}", trainStatusUpdate.getTrainNumber(), trainStatusUpdate.getTripId());
		railwayTrainRunningService.updateTrainStatus(trainStatusUpdate);
	}
}
