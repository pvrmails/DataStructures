package com.running.train.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.running.train.entities.RunningTrainStatus;
import com.running.train.entities.TrainQueryResponse;

@Repository
public interface RailwayTrainRunningRepository extends JpaRepository<RunningTrainStatus, Integer> {
	
	@Query(value = "update running_train_status set arrival_time = ?1, departure_time= ?2 where station_name = ?3 AND train_id=?4 AND trip_id=?5", nativeQuery = true)
	public void updateTrainRunningStatus(String arrivalTime, String departureTime, String stationName, int trainId,  int routeId);
	
	@Query(value = "select * from running_train_status where train_id=?1 AND trip_id= ?2", nativeQuery = true)
	public List<RunningTrainStatus> getTrainRunningStatus(int trainNumber, int tripId);
	
	@Query(value = "select r.train_id, r.station_name, r.arrival_time, r.departure_time from running_train_status r where trip_id=?1", nativeQuery = true)
	public List<TrainQueryResponse> getRunningTrain(int tripId);
}