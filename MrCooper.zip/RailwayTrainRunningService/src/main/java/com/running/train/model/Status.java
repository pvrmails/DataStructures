package com.running.train.model;

public enum Status {
	COMPLETE, STARTED
}
