package com.running.train.entities;

import java.util.Date;

public interface TrainQueryResponse {
	public int getTrain_id();

	public String getStation_name();

	public Date getArrival_time();

	public Date getDeparture_time();
}