package com.running.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayTrainRunningServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
