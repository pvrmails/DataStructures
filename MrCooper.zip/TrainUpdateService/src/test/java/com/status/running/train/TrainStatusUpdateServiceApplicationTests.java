package com.status.running.train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainStatusUpdateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
