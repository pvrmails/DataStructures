package com.status.running.train.model;

import java.io.Serializable;

public class TrainUpdateStatus implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int trainNumber;
	private int tripId;
	private String stationName;
	private String arrivedTime;
	private String departureTime;
	
	public String getStationName() {
		return stationName;
	}
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	public int getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(int trainNumber) {
		this.trainNumber = trainNumber;
	}
	
	public int getTripId() {
		return tripId;
	}
	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	public String getArrivedTime() {
		return arrivedTime;
	}
	public void setArrivedTime(String arrivedTime) {
		this.arrivedTime = arrivedTime;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}