package com.status.running.train.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.status.running.train.model.TrainUpdateStatus;
import com.status.running.train.service.RunningTrainStatusUpdateService;

@RestController("/train")
public class RunningTrainStatusUpdateController {
	
	private RunningTrainStatusUpdateService runningTrainStatusUpdateService;
	
	@Autowired
	public RunningTrainStatusUpdateController(RunningTrainStatusUpdateService runningTrainStatusUpdateService) {
		this.runningTrainStatusUpdateService = runningTrainStatusUpdateService;
	}

	@PostMapping("update")
	public String updateTrainStatus(@RequestBody TrainUpdateStatus trainUpdateStatus) throws ParseException {
		return runningTrainStatusUpdateService.postTrainStatus(trainUpdateStatus);
	}
}