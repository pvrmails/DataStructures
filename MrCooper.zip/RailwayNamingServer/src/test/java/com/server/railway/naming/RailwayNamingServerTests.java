package com.server.railway.naming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayNamingServerTests {

	@Test
	void contextLoads() {
	}

}
