package com.train.station.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.train.station.entities.Station;

@Repository
public interface SubjectRepository extends JpaRepository<Station, Long> 
{	 

}
