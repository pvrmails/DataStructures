package com.status.railway.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
