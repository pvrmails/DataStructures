package com.biller.product.discount.calculator;

import java.text.DecimalFormat;
import java.util.List;
import java.util.stream.Collectors;

import com.biller.model.InvoiceLineItem;

/**
 * Calculate discounts.
 * 
 * @author RAJASEKAR PV
 * 
 * @since 02 / 08 / 2020
 *
 */
public class ClearanceDiscountCalculator implements IDiscountCalculator {
	
    private static DecimalFormat numberFormatter = new DecimalFormat("0.00");


	@Override
	public List<InvoiceLineItem> calculateDiscountsForEveryItem(List<InvoiceLineItem> discountedItems, Float clearanceDiscount) {
		return discountedItems.stream()
							.map(item -> calculateDiscount(item, item.getName().contains("clearance") ? (1 - clearanceDiscount) : 1F)).collect(Collectors.toList());
	}

	private InvoiceLineItem calculateDiscount(InvoiceLineItem item, Float additionalClearanceDiscount) {
		Float discountPercentage = 1 - item.getDiscountPercent();
		item.setDiscountedPrice(item.getQuantity() * (item.getPrice() * discountPercentage) * additionalClearanceDiscount);
		return item;
	}

	public Float getDiscountedTotalPrice(List<InvoiceLineItem> discountedItem) {
		Float totalPrice =  discountedItem.stream().map(InvoiceLineItem::getDiscountedPrice).reduce(0.00F,
				(value1, value2) -> value1 + value2);
		return Float.parseFloat(numberFormatter.format(totalPrice));
	}
}
