package com.biller.product.discount;

import java.util.HashMap;
import java.util.Map;

/**
 * This class is a Singleton and holds centralized discount table for reference.
 * 
 * @author RAJASEKAR PV
 * 
 * @since 01 / 08 / 2020
 */
public class CategoryBasedDiscounter implements DiscountFetcher {
	/**
	 * This map is critical of holding all the discounts across categories
	 */
	private static Map<String, Float> categoryBasedDiscounts = new HashMap<>();

	private CategoryBasedDiscounter() {
	}

	private static CategoryBasedDiscounter categoryBasedDiscounter;

	public static CategoryBasedDiscounter getDiscounts() {
		if (categoryBasedDiscounter == null) {
			synchronized (CategoryBasedDiscounter.class) {
				if (categoryBasedDiscounter == null) {
					categoryBasedDiscounter = new CategoryBasedDiscounter();
				}
			}
		}
		return categoryBasedDiscounter;
	}


	static {
		categoryBasedDiscounts.put("books", 0.05F);
		categoryBasedDiscounts.put("food", 0.05F);
		categoryBasedDiscounts.put("drinks", 0.05F);
		categoryBasedDiscounts.put("clothes", 0.20F);                             
		categoryBasedDiscounts.put("others", 0.03F);
		categoryBasedDiscounts.put("clearance", 0.20F);
	}

	@Override
	public Map<String, Float> getDiscountPercent() {
		return categoryBasedDiscounts;
	}
}