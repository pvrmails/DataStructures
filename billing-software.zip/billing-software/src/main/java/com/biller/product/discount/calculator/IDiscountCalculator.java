package com.biller.product.discount.calculator;

import java.util.List;

import com.biller.model.InvoiceLineItem;

public interface IDiscountCalculator {

	public List<InvoiceLineItem> calculateDiscountsForEveryItem(List<InvoiceLineItem> discountedItems, Float clearanceDiscount);

	public Float getDiscountedTotalPrice(List<InvoiceLineItem> discountedItem);
	
}