package com.biller.product;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.biller.exception.NoSuchProductException;
import com.biller.model.BasketLineItems;
import com.biller.model.Product;

public class ProductCatalog {
	/**
	 * Look into the product catalog for the categories. productName -> Product
	 * itself in the map.
	 */
	private static Map<String, Product> productDiscounts = new HashMap<>();

	// Ideally products can be created by using Factories.
	// Seed the data into the product catalog.
	static {
		productDiscounts.put("book", new Product("book", 0.0F, "books"));
		productDiscounts.put("shirt", new Product("shirt", 0.0F, "clothes"));
		productDiscounts.put("chocolate bar", new Product("chocolate bar", 0.0F, "food"));
		productDiscounts.put("clearance chocolate bar", new Product("clearance chocolate bar", 0.0F, "food"));
		productDiscounts.put("bottle of perfume", new Product("bottle of perfume", 0.0F, "others"));
		productDiscounts.put("bottle of wine", new Product("bottle of wine", 0.0F, "drinks"));
		productDiscounts.put("dress", new Product("dress ", 0.0F, "clothes"));
		productDiscounts.put("box of chocolates", new Product("box of chocolates", 0.0F, "books"));
	}

	// Get the Category for getting the discounts.
	public List<Product> getCategorizedProducts(List<BasketLineItems> billerItems) {
		return billerItems.stream().map(billItem -> getProduct(billItem)).collect(Collectors.toList());
	}

	private Product getProduct(BasketLineItems billerItem) {
		Product product = productDiscounts.get(billerItem.getProductName());
		if(product == null) {
			throw new NoSuchProductException("Invalid Product detected : " + billerItem.getProductName());
		}
		product.setQuantity(billerItem.getQuantity());		
		product.setPrice(billerItem.getPrice());
		return product;
	}
}
