package com.biller.product.discount;

import java.util.Map;

/**
 * This interface will get the discount percentage for the given type.
 * 
 * @author RAJASEKAR PV
 * 
 * @since 01 / 08 / 2020
 */
public interface DiscountFetcher {
	
	Map<String, Float> getDiscountPercent();
	
}