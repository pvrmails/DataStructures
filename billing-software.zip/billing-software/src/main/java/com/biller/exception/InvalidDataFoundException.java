package com.biller.exception;

public class InvalidDataFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidDataFoundException(String message) {
		super(message);
	}

	public InvalidDataFoundException(String message, Throwable cause) {
		super(message, cause);
	}
}