package com.biller.exception;

public class NoSuchProductException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NoSuchProductException(String message) {
		super(message);
	}

	public NoSuchProductException(String message, Throwable cause) {
		super(message, cause);
	}
}