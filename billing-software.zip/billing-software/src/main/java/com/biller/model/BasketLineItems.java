package com.biller.model;

public class BasketLineItems {

	private int quantity;

	private String productName;

	private float price;

	public int getQuantity() {
		return quantity;
	}

	public BasketLineItems(int quantity, String productName, float price) {
		this.quantity = quantity;
		this.productName = productName;
		this.price = price;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
}
