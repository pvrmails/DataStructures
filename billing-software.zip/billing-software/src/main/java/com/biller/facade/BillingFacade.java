package com.biller.facade;

import java.text.DecimalFormat;
import java.util.List;
import java.util.stream.Collectors;

import com.biller.exception.InvalidDataFoundException;
import com.biller.model.BasketLineItems;
import com.biller.model.InvoiceLineItem;
import com.biller.product.discount.CategoryBasedDiscounter;
import com.biller.product.discount.calculator.ClearanceDiscountCalculator;
import com.biller.product.discount.calculator.IDiscountCalculator;
import com.biller.service.DiscountBillerService;

/**
 * Singleton instance and can there be only one Billing Facade for the whole
 * shop.
 * 
 * @author RAJASEKAR PV
 * 
 * @since 02 / 08 / 2020
 *
 */
public class BillingFacade {

	private static BillingFacade billingFacade;
	
    private static final DecimalFormat placeFormatter = new DecimalFormat("0.00");
	
	private static final String CLEARANCE_DISCOUNT = "clearance";

	private BillingFacade() {
	}

	public static BillingFacade getBillingFacade() {
		if (billingFacade == null) {
			synchronized (BillingFacade.class) {
				if (billingFacade == null) {
					billingFacade = new BillingFacade();
				}
			}
		}
		return billingFacade;
	}

	private List<BasketLineItems> parseBillingInputRequest(List<String> itemList) {
		return itemList.stream().map(item -> parseSingleBillItem(item)).collect(Collectors.toList());
	}

	private BasketLineItems parseSingleBillItem(String itemBill) {
		Float price = null;
		int quantity = 0;
		String productName;
		try {
			price = Float.parseFloat(itemBill.substring(itemBill.lastIndexOf(" ")).trim());
			quantity = Integer.parseInt(itemBill.substring(0, itemBill.indexOf(" ")).trim());
			productName = itemBill.substring(itemBill.indexOf(" "), itemBill.indexOf(" at ")).trim();
		} catch (InvalidDataFoundException  | NumberFormatException nfe) {
			 throw new InvalidDataFoundException("Invalid Item found check for the validity of the entered data." + nfe.getLocalizedMessage());
		}
		return new BasketLineItems(quantity, productName, price);
	}
	

	/**
	 * Prints the results to the screen after calculating the bills.
	 * @param billerResponse --> Discounted Billed items.
	 * @param billerRequest  --> Actual Billed items.
	 */
	public List<InvoiceLineItem> printDiscountedBill(List<String> billingItems) {
		List<BasketLineItems> billerRequest = parseBillingInputRequest(billingItems);

		DiscountBillerService discountBillerService = new DiscountBillerService();

		// Find the discount rates and set it in discount response.
		List<InvoiceLineItem> disCountedResponse = discountBillerService.getDisCountedItems(billerRequest);

		// Print the bill to the screen / printer
		printBill(getActualTotalPrice(billerRequest), getTotalDiscountedPrice(disCountedResponse), disCountedResponse);
		
		return disCountedResponse;
	}
	
	/**
	 * Calculates the actual price before applying any discount
	 * @param basketLineItem
	 * @return price without discount
	 */
	private Float getActualTotalPrice(List<BasketLineItems> basketLineItem) {
		return basketLineItem.stream().map(BasketLineItems::getPrice).reduce(0.00F,
				(value1, value2) -> value1 + value2);
	}
	
	/**
	 * Calculates the discounted price after applying discount
	 * @param disCountedResponse
	 * @return discounted total price of the cart.
	 */
	private Float getTotalDiscountedPrice(List<InvoiceLineItem> disCountedResponse) {
		IDiscountCalculator discountCalculator = new ClearanceDiscountCalculator();
		return discountCalculator
				.getDiscountedTotalPrice(discountCalculator.calculateDiscountsForEveryItem(disCountedResponse,
						CategoryBasedDiscounter.getDiscounts().getDiscountPercent().get(CLEARANCE_DISCOUNT)));
	}

	/**
	 * It just prints the bill.
	 * @param actualPrice
	 * @param discountedPrice
	 * @param billerResponse
	 */
	private void printBill(Float actualPrice, Float discountedPrice, List<InvoiceLineItem> billerResponse) {
		System.out.println("Generated Bill");
		System.out.println("==============");
		billerResponse.stream().forEach(billedItem -> {
			System.out.println(
					billedItem.getQuantity() + " " + billedItem.getName() + " at " + placeFormatter.format(billedItem.getDiscountedPrice()));
		});
		System.out.println("Total : " + placeFormatter.format(discountedPrice));
		float savings = actualPrice - discountedPrice;
		System.out.println(savings > 0 ? "You Saved : " + placeFormatter.format(actualPrice - discountedPrice) : "");
	}
}