package com.biller.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.biller.model.BasketLineItems;
import com.biller.model.InvoiceLineItem;
import com.biller.model.Product;
import com.biller.product.ProductCatalog;
import com.biller.product.discount.CategoryBasedDiscounter;

/**
 * Service class that is responsible for look up product catalog to fetch
 * categories and finding discounts based on the found category type.
 * 
 * @author RAJASEKAR PV
 *
 * @since 02 / 08 / 2020.
 */
public class DiscountBillerService {

	public List<InvoiceLineItem> getDisCountedItems(List<BasketLineItems> billerItems) {
		// Get the name and go to the product catalog to fetch the category
		List<Product> productList = new ProductCatalog().getCategorizedProducts(billerItems);

		// Fetch the discounts for the various categories..
		Map<String, Float> categoryDiscountMap = CategoryBasedDiscounter.getDiscounts().getDiscountPercent();

		return productList.stream().map(product -> getDiscount(product, categoryDiscountMap))
				.collect(Collectors.toList());

	}

	private InvoiceLineItem getDiscount(Product product, Map<String, Float> categoryDiscountList) {
		InvoiceLineItem discountedItem = new InvoiceLineItem();
		discountedItem.setName(product.getProductName());
		discountedItem.setPrice(product.getPrice());
		discountedItem.setDiscountPercent(categoryDiscountList.get(product.getCategoryName()));
		discountedItem.setQuantity(product.getQuantity());
		return discountedItem;
	}
}