package com.bill.product.scanner;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.biller.facade.BillingFacade;

/**
 * @author RAJASEKAR PV
 * 
 * @since 02 / 08 / 2020.
 */
public class BillingSystem {

	public static void main(String[] args) {
		BillingSystem billSystem = new BillingSystem();
		List<String> itemsToBill = billSystem.readItemsToBill();
		BillingFacade.getBillingFacade().printDiscountedBill(itemsToBill);
	}

	//This represents the billing scanner.
	private List<String> readItemsToBill() {
		List<String> billedItems = new ArrayList<>();
		try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Enter the number of items to bill : ");
			String numberOfItems = scanner.nextLine();
			for (int item = 1; item <= Integer.parseInt(numberOfItems); item++) {
				System.out.print("Enter item # " + item + " : ");
				String scannedItem = scanner.nextLine();
				billedItems.add(scannedItem);
			}
		}
		return billedItems;
	}
}