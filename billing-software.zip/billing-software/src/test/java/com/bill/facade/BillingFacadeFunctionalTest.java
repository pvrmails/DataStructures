package com.bill.facade;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.biller.facade.BillingFacade;
import com.biller.model.InvoiceLineItem;

@RunWith(JUnitPlatform.class)
public class BillingFacadeFunctionalTest {
	
	@Test
	public void testValidDiscountPercentageAndPriceForSingleItem() {
		List<String> testBill = Arrays.asList("1 book at 14.49"); 
		List<InvoiceLineItem>  invoiceItem = BillingFacade.getBillingFacade().printDiscountedBill(testBill);
		Float actualDiscountPrice = invoiceItem.get(0).getDiscountedPrice();
		Float actualDiscountPercent = invoiceItem.get(0).getDiscountPercent();
		Assert.assertTrue("Calculated discout percentage is wrong !!", actualDiscountPercent == 0.05F);
		Assert.assertTrue("Calculated discout price is wrong !!", actualDiscountPrice == 13.7655F);
	}
	
	@Test
	public void testValidDiscountPercentageAndPriceForManyItems() {
		List<String> testBill = Arrays.asList("1 book at 14.49", "1 shirt at 19.99"); 
		List<InvoiceLineItem>  invoiceItem = BillingFacade.getBillingFacade().printDiscountedBill(testBill);
		Float actualDiscountPrice = invoiceItem.get(0).getDiscountedPrice();
		Float actualDiscountPercent = invoiceItem.get(0).getDiscountPercent();
		Assert.assertTrue("Calculated discout percentage is wrong !!", actualDiscountPercent == 0.05F);
		Assert.assertTrue("Calculated discout price is wrong !!", actualDiscountPrice == 13.7655F);
		Float actualDiscountPrice1 = invoiceItem.get(1).getDiscountedPrice();
		Float actualDiscountPercent1 = invoiceItem.get(1).getDiscountPercent();
		Assert.assertTrue("Calculated discout percentage is wrong !!", actualDiscountPercent1 == 0.2F);
		Assert.assertTrue("Calculated discout price is wrong !!", actualDiscountPrice1 == 15.992F);
	}
}
