package com.bill.facade;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.biller.exception.InvalidDataFoundException;
import com.biller.exception.NoSuchProductException;
import com.biller.facade.BillingFacade;

@RunWith(JUnitPlatform.class)
public class BillerFacadeExceptionHandlerTest {
	
	@Test(expected = InvalidDataFoundException.class)
	public void testWithInvalidQuantity() {
		List<String> testBill = Arrays.asList("invalidQuantity chocolate 23.4", "adfa bottle of wine 24.23"); 
		BillingFacade.getBillingFacade().printDiscountedBill(testBill);
	}
	
	@Test(expected = NoSuchProductException.class)
	public void testWithInvalidProductItem() {
		List<String> testBill = Arrays.asList("1 invalidItem at 14.49"); 
		BillingFacade.getBillingFacade().printDiscountedBill(testBill);
	}
	
	@Test(expected = InvalidDataFoundException.class)
	public void testWithInvalidPrice() {
		List<String> testBill = Arrays.asList("1 invalidItem at aasdf"); 
		BillingFacade.getBillingFacade().printDiscountedBill(testBill);
	}
}