package com.bill.facade.service;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

import com.biller.model.BasketLineItems;
import com.biller.model.InvoiceLineItem;
import com.biller.service.DiscountBillerService;

@RunWith(JUnitPlatform.class)
public class BillingServiceTest {
	
	@Test
	public void testGetDiscountedItems() {
		DiscountBillerService discounterService = new DiscountBillerService();
		BasketLineItems item1 = new BasketLineItems(1, "shirt", 12.34F);
		BasketLineItems item2 = new BasketLineItems(1, "clearance chocolate bar", 2.00F);
		List<InvoiceLineItem> invoiceItems = discounterService.getDisCountedItems(Arrays.asList(item1, item2));
		Assert.assertTrue("Discount percentage is wrong", invoiceItems.get(1).getDiscountPercent() == 0.05F);
		Assert.assertTrue("Discount percent is wrong", invoiceItems.get(0).getDiscountPercent() == 0.2F);
	}
}
